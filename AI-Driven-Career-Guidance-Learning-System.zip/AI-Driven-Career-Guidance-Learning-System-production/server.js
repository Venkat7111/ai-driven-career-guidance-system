const express = require('express');
const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '.env') }); // Explicitly specify .env path

// Debug log to confirm if .env is loaded
console.log("Loaded Environment Variables:", process.env);

console.log("OpenRouter API Key:", process.env.OPENROUTER_API_KEY); // Debug log
console.log("YouTube API Key:", process.env.YOUTUBE_API_KEY); // Debug log

const apiRouter = require('./routes/api'); // Import the api.js router

const openRouterApiKey = process.env.OPENROUTER_API_KEY;
const youtubeApiKey = process.env.YOUTUBE_API_KEY;

if (!openRouterApiKey || !youtubeApiKey) {
    console.error("Error: Missing API keys. Please set OPENROUTER_API_KEY and YOUTUBE_API_KEY in the .env file.");
    process.exit(1);
}

const app = express();
const PORT = process.env.PORT || 3001; // Change default port to 3001

// Middleware to parse JSON bodies
app.use(express.json());

// Use the API router for routes starting with /api
app.use('/api', apiRouter);

// Serve static files from the "public" directory
app.use(express.static(path.join(__dirname, 'public')));

// Serve the index.html file for all other routes
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
